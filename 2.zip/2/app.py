"""
SafeTrak  Mining Systems, Safety and Equipment Monitoring App  (MINN2020A prototype)

Run:   streamlit run app.py
Data:  CSV files are kept in a "data" folder next to this file. Missing files are
       created with sample data on first run; older CSVs are upgraded automatically.
Note:  All thresholds are educational prototype values, NOT manufacturer or mine
       safety limits.
"""
import hashlib
import hmac
import html
import re
import secrets
from datetime import date, datetime, timedelta
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="SafeTrak", page_icon="MS", layout="wide", initial_sidebar_state="expanded")

# ======================================================================================
# CONFIGURATION
# ======================================================================================
DATA_DIR = Path(__file__).parent / "data"
DATA_DIR.mkdir(exist_ok=True)

PAGES = ["Dashboard", "Worker Safety", "Incidents", "Equipment", "Maintenance",
         "Risk Assessment", "Analytics", "Reports", "User Management"]
ROLES = ["Administrator", "Safety Officer", "Mining Engineer", "Maintenance Engineer", "Manager"]
PERMISSIONS = {  # follows Table 1 of the project brief
    "Administrator": set(PAGES),
    "Safety Officer": {"Dashboard", "Worker Safety", "Incidents", "Risk Assessment", "Analytics", "Reports"},
    "Mining Engineer": set(PAGES) - {"User Management"},
    "Maintenance Engineer": {"Dashboard", "Equipment", "Maintenance", "Analytics", "Reports"},
    "Manager": set(PAGES) - {"User Management"},
}

# Prototype thresholds (educational only)
TEMP_WARN, TEMP_CRIT = 80, 100          # deg C
VIB_WARN, VIB_CRIT = 5, 8               # mm/s
PPE_MIN = 80                            # % PPE compliance
FATIGUE_HIGH = 4                        # 1-5 scale
LOW_AVAIL = 85                          # % availability
HIGH_DOWNTIME = 48                      # hours
DUE_SOON_DAYS = 7                       # maintenance "due" window

DEFAULT_DEPTS = ["Underground Mining", "Surface Mining", "Processing", "Engineering", "Maintenance", "Safety & Health", "Logistics"]
INCIDENT_TYPES = ["Fall of ground", "Slip / trip / fall", "Vehicle collision", "Equipment failure", "Fire / explosion",
                  "Electrical", "Hazardous substance", "Machinery contact", "Near miss", "Other"]
EQUIPMENT_TYPES = ["Haul truck", "Loader", "Excavator", "Drilling machine", "Bulldozer", "Scraper winch", "Crusher", "Conveyor", "Other"]
SEV_COLORS = {"Low": "#77a69b", "Medium": "#e6a23c", "High": "#df7657", "Critical": "#b8382d"}
STATUS_COLORS = {"NORMAL": "#16735f", "WARNING": "#e6a23c", "CRITICAL": "#b8382d"}

SCHEMAS = {
    "workers": ["Worker ID", "Name", "Department", "Job Role", "Shift", "PPE Compliance", "Training", "Fatigue",
                "Safety Observations", "Near Misses", "Previous Incidents", "Risk Level"],
    "incidents": ["Incident ID", "Date", "Time", "Shift", "Location", "Department", "Incident Type", "Severity",
                  "Injury Status", "Lost Time Injury", "Cause", "Corrective Action", "Corrective Action Status"],
    "equipment": ["Equipment ID", "Equipment Type", "Manufacturer", "Location", "Operating Hours", "Temperature", "Vibration",
                  "Fuel Consumption", "Brake Status", "Tyre Status", "Engine Status", "Maintenance Status", "Downtime",
                  "Availability", "Last Maintenance", "Next Maintenance"],
    "maintenance": ["Work Order ID", "Equipment ID", "Task", "Assigned To", "Priority", "Status", "Scheduled Date",
                    "Completed Date", "Downtime (hours)", "Notes"],
    "risk": ["Assessment ID", "Date", "Location", "Department", "Hazard", "People at Risk", "Existing Controls", "Likelihood",
             "Consequence", "Risk Score", "Risk Level", "Additional Controls", "Assessed By", "Review Date", "Status"],
    "users": ["Username", "Name", "Role", "Salt", "Password Hash"],
}
NUMERIC = {
    "workers": ["PPE Compliance", "Fatigue", "Near Misses", "Previous Incidents"],
    "equipment": ["Operating Hours", "Temperature", "Vibration", "Fuel Consumption", "Downtime", "Availability"],
    "maintenance": ["Downtime (hours)"],
    "risk": ["Likelihood", "Consequence", "Risk Score"],
}
FILES = {"workers": DATA_DIR / "workers.csv", "incidents": DATA_DIR / "incidents.csv", "equipment": DATA_DIR / "equipment.csv",
         "maintenance": DATA_DIR / "maintenance.csv", "risk": DATA_DIR / "risk_assessments.csv", "users": DATA_DIR / "users.csv"}

ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_\-]{1,29}$")
ID_HELP = "IDs use letters, numbers, - and _ (2-30 characters)."
ALERT_COLS = ["Level", "Category", "ID", "Parameter", "Value", "Status", "Action"]
ALERT_PERM = {"Equipment": "Equipment", "Maintenance": "Maintenance", "Worker": "Worker Safety", "Incident": "Incidents", "Risk": "Risk Assessment"}
ID_LABEL = {"Equipment": "Equipment ID", "Maintenance": "Equipment ID", "Worker": "Worker ID", "Incident": "Incident ID", "Risk": "Assessment ID"}
ACT_INSPECT = "Inspect equipment and initiate appropriate maintenance/safety procedures."
ALIASES = {"maint": "maintenance"}


# ======================================================================================
# PASSWORDS AND USERS
# ======================================================================================
def hash_pw(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), 120_000).hex()


def make_user(username, name, role, password):
    salt = secrets.token_hex(16)
    return {"Username": username.strip().lower(), "Name": name.strip(), "Role": role, "Salt": salt, "Password Hash": hash_pw(password, salt)}


def seed_users():
    return pd.DataFrame([make_user("admin", "Hletelo", "Administrator", "admin123"),
                         make_user("safety", "Lilitha", "Safety Officer", "safety123"),
                         make_user("mining", "Milka", "Mining Engineer", "mining123"),
                         make_user("maintenance", "Vuyo","Maintenance Engineer", "maint123"),
                         make_user("manager", "Innocent","Manager", "manager123")])


def verify_user(username, password):
    users = get("users")
    name = ALIASES.get(username.strip().lower(), username.strip().lower())
    row = users[users["Username"] == name]
    if row.empty:
        return None
    r = row.iloc[0]
    try:
        ok = hmac.compare_digest(hash_pw(password, r["Salt"]), str(r["Password Hash"]))
    except ValueError:
        ok = False
    return {"Username": r["Username"], "Name": r["Name"], "Role": r["Role"]} if ok else None


# ======================================================================================
# DOMAIN RULES
# ======================================================================================
def worker_risk_level(r):
    pts = 0
    if pd.notna(r["PPE Compliance"]):
        pts += 3 if r["PPE Compliance"] < 60 else 2 if r["PPE Compliance"] < PPE_MIN else 0
    if pd.notna(r["Fatigue"]):
        pts += 3 if r["Fatigue"] >= 5 else 2 if r["Fatigue"] >= FATIGUE_HIGH else 0
    pts += 0 if str(r["Training"]) == "Complete" else 1
    pts += 1 if r["Near Misses"] >= 3 else 0
    pts += 1 if r["Previous Incidents"] >= 2 else 0
    return "Low" if pts <= 1 else "Medium" if pts <= 3 else "High" if pts <= 5 else "Critical"


def worker_warnings(r):
    w = []
    if r["PPE Compliance"] < PPE_MIN:
        w.append(f"PPE compliance {r['PPE Compliance']:.0f}% (below {PPE_MIN}%)")
    if r["Fatigue"] >= FATIGUE_HIGH:
        w.append(f"High fatigue level ({r['Fatigue']:.0f}/5)")
    if str(r["Training"]) != "Complete":
        w.append("Safety training not complete")
    if r["Near Misses"] >= 3:
        w.append(f"{int(r['Near Misses'])} near misses recorded")
    if r["Risk Level"] in ("High", "Critical"):
        w.append(f"{r['Risk Level']} worker risk level")
    return w


def equipment_status(r):
    if r["Temperature"] > TEMP_CRIT or r["Vibration"] > VIB_CRIT:
        return "CRITICAL"
    if r["Temperature"] >= TEMP_WARN or r["Vibration"] >= VIB_WARN:
        return "WARNING"
    return "NORMAL"


def equipment_message(r):
    t, v = r["Temperature"], r["Vibration"]
    if v > VIB_CRIT:
        return "CRITICAL: Equipment vibration exceeds predefined threshold. Inspection required."
    if t > TEMP_CRIT:
        return "CRITICAL: Equipment temperature exceeds predefined threshold. Inspection required."
    if t >= TEMP_WARN:
        return "WARNING: Equipment temperature approaching predefined threshold."
    if v >= VIB_WARN:
        return "WARNING: Equipment vibration approaching predefined threshold."
    return "NORMAL: Equipment operating within defined monitoring limits."


def availability(operating, downtime):
    total = operating + downtime
    return round(operating / total * 100, 1) if total > 0 else 0.0


def classify_risk(score):
    return "Low" if score <= 4 else "Medium" if score <= 9 else "High" if score <= 16 else "Critical"


def _next_date(r):
    return pd.to_datetime(r["Next Maintenance"], errors="coerce")


def is_overdue(r):
    if r["Maintenance Status"] == "Under maintenance":
        return False
    nxt = _next_date(r)
    return r["Maintenance Status"] == "Overdue" or (pd.notna(nxt) and nxt.date() < date.today())


def is_due(r):
    if r["Maintenance Status"] == "Under maintenance" or is_overdue(r):
        return False
    nxt = _next_date(r)
    return r["Maintenance Status"] == "Due" or (pd.notna(nxt) and nxt.date() <= date.today() + timedelta(days=DUE_SOON_DAYS))


def mask(df, fn):
    return pd.Series([bool(fn(r)) for _, r in df.iterrows()], index=df.index, dtype=bool)


# ======================================================================================
# DATA LAYER (CSV storage)
# ======================================================================================
def ensure(df, key):
    """Add missing schema columns, tidy types, keep any extra columns."""
    cols, num = SCHEMAS[key], NUMERIC.get(key, [])
    df = df.copy()
    for c in cols:
        if c not in df.columns:
            df[c] = ""
    for c in df.columns:
        if c in num:
            df[c] = pd.to_numeric(df[c], errors="coerce")
        else:
            df[c] = df[c].fillna("").astype(str).str.strip()
    return df[cols + [c for c in df.columns if c not in cols]]


def clean_workers(df):
    df = ensure(df, "workers")
    df[["Near Misses", "Previous Incidents"]] = df[["Near Misses", "Previous Incidents"]].fillna(0)
    blank = df["Risk Level"] == ""
    if blank.any():
        df.loc[blank, "Risk Level"] = [worker_risk_level(r) for _, r in df[blank].iterrows()]
    return df


def clean_incidents(df):
    if "Status" in df.columns:  # older versions saved the status under this name
        if "Corrective Action Status" in df.columns:
            df["Corrective Action Status"] = df["Corrective Action Status"].fillna(df["Status"])
            df = df.drop(columns=["Status"])
        else:
            df = df.rename(columns={"Status": "Corrective Action Status"})
    return ensure(df, "incidents")


def clean_equipment(df):
    df = ensure(df, "equipment").drop(columns=["Alert Status"], errors="ignore")
    total = df["Operating Hours"] + df["Downtime"].fillna(0)
    calc = (df["Operating Hours"] / total * 100).round(1)
    df["Availability"] = calc.where(df["Operating Hours"].notna() & (total > 0), df["Availability"])
    df["Alert Status"] = [equipment_status(r) for _, r in df.iterrows()]
    return df


CLEAN = {"workers": clean_workers, "incidents": clean_incidents, "equipment": clean_equipment,
         "maintenance": lambda df: ensure(df, "maintenance"), "risk": lambda df: ensure(df, "risk"),
         "users": lambda df: ensure(df, "users")}


def _days_ago(n):
    return str(date.today() - timedelta(days=n))


def _days_ahead(n):
    return str(date.today() + timedelta(days=n))


def seed(key):
    if key == "users":
        return seed_users()
    if key == "workers":
        rows = [["W001", "Thabo Mokoena", "Underground Mining", "Rock drill operator", "Day", 95, "Complete", 2, "Good housekeeping", 0, 0],
                ["W002", "Lerato Dlamini", "Underground Mining", "Team leader", "Night", 72, "Complete", 4, "Fatigue after double shift", 2, 1],
                ["W003", "Sipho Nkosi", "Surface Mining", "Haul truck operator", "Day", 88, "Complete", 3, "", 1, 0],
                ["W004", "Naledi Khumalo", "Processing", "Plant operator", "Day", 91, "Due", 2, "", 0, 0],
                ["W005", "Johan van Wyk", "Maintenance", "Fitter", "Night", 64, "Expired", 5, "Guard removed on conveyor", 4, 2],
                ["W006", "Zanele Mahlangu", "Engineering", "Mining engineer", "Day", 98, "Complete", 1, "", 0, 0],
                ["W007", "Pieter Botha", "Surface Mining", "Drill operator", "Night", 79, "Complete", 4, "", 3, 1],
                ["W008", "Ayanda Zulu", "Safety & Health", "Safety officer", "Day", 100, "Complete", 2, "Toolbox talk delivered", 0, 0]]
        df = pd.DataFrame(rows, columns=SCHEMAS["workers"][:-1])
        df["Risk Level"] = [worker_risk_level(r) for _, r in df.iterrows()]
        return df
    if key == "incidents":
        rows = [["INC-001", _days_ago(75), "06:30", "Day", "Stope 4", "Underground Mining", "Fall of ground", "High", "Medical treatment", "Yes", "Loose hanging wall", "Re-scale and install support", "Closed"],
                ["INC-002", _days_ago(62), "22:15", "Night", "Haul road B", "Surface Mining", "Vehicle collision", "Medium", "First aid", "No", "Poor visibility", "Improve road lighting", "Closed"],
                ["INC-003", _days_ago(48), "14:05", "Day", "Crusher 1", "Processing", "Equipment failure", "Medium", "No injury", "No", "Bearing failure", "Replace bearings", "Closed"],
                ["INC-004", _days_ago(41), "02:40", "Night", "Stope 7", "Underground Mining", "Near miss", "Low", "No injury", "No", "Unsecured tools", "Tool tethering", "Closed"],
                ["INC-005", _days_ago(33), "09:20", "Day", "Workshop", "Maintenance", "Machinery contact", "High", "Medical treatment", "Yes", "Guard removed", "Reinstall guards, retrain", "Under Investigation"],
                ["INC-006", _days_ago(27), "23:50", "Night", "Conveyor 2", "Processing", "Slip / trip / fall", "Low", "First aid", "No", "Spillage", "Housekeeping plan", "Closed"],
                ["INC-007", _days_ago(19), "04:10", "Night", "Stope 4", "Underground Mining", "Fall of ground", "Critical", "Fatality", "Yes", "Support failure", "Full investigation and support review", "Open"],
                ["INC-008", _days_ago(12), "11:30", "Day", "Pit 2", "Surface Mining", "Equipment failure", "Medium", "No injury", "No", "Hydraulic leak", "Hose replacement", "Open"],
                ["INC-009", _days_ago(6), "20:45", "Night", "Haul road B", "Surface Mining", "Near miss", "Low", "No injury", "No", "Fatigue", "Review rosters", "Open"],
                ["INC-010", _days_ago(2), "07:15", "Day", "Stope 7", "Underground Mining", "Hazardous substance", "Medium", "First aid", "No", "Poor ventilation", "Ventilation check", "Open"]]
        return pd.DataFrame(rows, columns=SCHEMAS["incidents"])
    if key == "equipment":
        rows = [["TRK-012", "Haul truck", "Caterpillar", "Haul road B", 620, 92, 9.2, 38, "Fair", "Good", "Fair", "Due", 40, "", _days_ago(80), _days_ahead(3)],
                ["TRK-014", "Haul truck", "Komatsu", "Pit 2", 700, 74, 3.1, 35, "Good", "Good", "Good", "Up to date", 12, "", _days_ago(20), _days_ahead(70)],
                ["LDR-003", "Loader", "Sandvik", "Stope 4", 540, 83, 4.2, 22, "Good", "Fair", "Good", "Overdue", 95, "", _days_ago(150), _days_ago(10)],
                ["EXC-001", "Excavator", "Hitachi", "Pit 2", 680, 68, 2.4, 41, "Good", "Good", "Good", "Up to date", 8, "", _days_ago(30), _days_ahead(60)],
                ["DRL-005", "Drilling machine", "Epiroc", "Stope 7", 450, 105, 6.1, 18, "Good", "Poor", "Fair", "Under maintenance", 120, "", _days_ago(5), _days_ahead(25)],
                ["CRU-001", "Crusher", "Metso", "Crusher 1", 700, 79, 7.5, 0, "Good", "Good", "Good", "Scheduled", 20, "", _days_ago(45), _days_ahead(15)],
                ["CNV-002", "Conveyor", "Bonfiglioli", "Conveyor 2", 710, 55, 1.9, 0, "Good", "Good", "Good", "Up to date", 5, "", _days_ago(10), _days_ahead(80)],
                ["BLD-001", "Bulldozer", "Caterpillar", "Pit 2", 600, 71, 3.8, 30, "Good", "Good", "Good", "Up to date", 18, "", _days_ago(25), _days_ahead(55)]]
        return pd.DataFrame(rows, columns=SCHEMAS["equipment"])
    return pd.DataFrame(columns=SCHEMAS[key])


def load(key):
    path = FILES[key]
    if not path.exists():
        seed(key).to_csv(path, index=False)
    try:
        return pd.read_csv(path, dtype=str)
    except pd.errors.EmptyDataError:
        return pd.DataFrame(columns=SCHEMAS[key])
    except Exception as exc:  # corrupt file: show a message instead of crashing
        st.error(f"Could not read {path.name}: {exc}")
        st.stop()


def get(key):
    return CLEAN[key](load(key))


def write(key, df):
    if key == "equipment":
        df = df.drop(columns=["Alert Status"], errors="ignore")
    df.to_csv(FILES[key], index=False)


def append_row(key, record):
    df = get(key)
    new = pd.DataFrame([record])
    df = new if df.empty else pd.concat([df, new], ignore_index=True)
    write(key, ensure(df, key))


def update_cells(key, id_col, ident, changes):
    df = get(key)
    m = df[id_col].astype(str) == str(ident)
    if not m.any():
        return False
    for col, val in changes.items():
        df.loc[m, col] = val
    write(key, df)
    return True


def id_exists(df, col, value):
    return value.strip().lower() in df[col].astype(str).str.strip().str.lower().values


def merged(defaults, *series):
    vals = set(defaults)
    for s in series:
        vals.update(v for v in s.astype(str) if v.strip())
    return sorted(vals)


def counts(series, label="Category"):
    vc = series.value_counts()
    return pd.DataFrame({label: vc.index.astype(str), "Count": vc.values})


# ======================================================================================
# ALERTS
# ======================================================================================
def build_alerts(d):
    rows = []

    def add(level, cat, ident, param, value, status, action):
        rows.append([level, cat, str(ident), param, value, status, action])

    for _, r in d["equipment"].iterrows():
        eid = r["Equipment ID"]
        if r["Vibration"] > VIB_CRIT:
            add("CRITICAL", "Equipment", eid, "Vibration", f"{r['Vibration']:.1f} mm/s", "Above Critical Threshold", ACT_INSPECT)
        elif r["Vibration"] >= VIB_WARN:
            add("WARNING", "Equipment", eid, "Vibration", f"{r['Vibration']:.1f} mm/s", "In Warning Range", "Monitor closely and schedule an inspection.")
        if r["Temperature"] > TEMP_CRIT:
            add("CRITICAL", "Equipment", eid, "Temperature", f"{r['Temperature']:.1f} C", "Above Critical Threshold", ACT_INSPECT)
        elif r["Temperature"] >= TEMP_WARN:
            add("WARNING", "Equipment", eid, "Temperature", f"{r['Temperature']:.1f} C", "In Warning Range", "Monitor closely and check cooling.")
        if r["Downtime"] >= HIGH_DOWNTIME:
            add("WARNING", "Equipment", eid, "Downtime", f"{r['Downtime']:.0f} h", "Excessive Downtime", "Investigate causes of downtime.")
        if r["Availability"] < LOW_AVAIL:
            add("WARNING", "Equipment", eid, "Availability", f"{r['Availability']:.1f}%", f"Below {LOW_AVAIL}%", "Review reliability and maintenance plan.")
        for comp in ("Brake Status", "Tyre Status", "Engine Status"):
            if str(r[comp]).lower() == "poor":
                add("WARNING", "Equipment", eid, comp.replace(" Status", ""), "Poor", "Component Condition Poor", "Inspect and repair component.")
        if is_overdue(r):
            add("WARNING", "Maintenance", eid, "Maintenance", "Overdue", "Overdue Maintenance", "Schedule maintenance and update the record.")
    for _, r in d["workers"].iterrows():
        if r["PPE Compliance"] < PPE_MIN:
            add("WARNING", "Worker", r["Worker ID"], "PPE compliance", f"{r['PPE Compliance']:.0f}%", f"Below {PPE_MIN}%", "Brief worker and supervisor; verify PPE before shift.")
        if r["Fatigue"] >= FATIGUE_HIGH:
            add("CRITICAL" if r["Fatigue"] >= 5 else "WARNING", "Worker", r["Worker ID"], "Fatigue level", f"{r['Fatigue']:.0f}/5", "High Fatigue", "Review workload and rest period before next shift.")
    for _, r in d["incidents"].iterrows():
        if r["Severity"] == "Critical" and r["Corrective Action Status"] != "Closed":
            add("CRITICAL", "Incident", r["Incident ID"], "Severity", "Critical", "Critical Incident Not Closed", "Complete investigation and corrective actions.")
    for _, r in d["risk"].iterrows():
        if r["Risk Level"] in ("High", "Critical") and r["Status"] != "Closed":
            add("CRITICAL" if r["Risk Level"] == "Critical" else "WARNING", "Risk", r["Assessment ID"], "Risk score",
                f"{r['Risk Score']:.0f} ({r['Risk Level']})", "High-Risk Observation", "Review controls with responsible safety personnel.")
    df = pd.DataFrame(rows, columns=ALERT_COLS)
    df["_o"] = df["Level"].map({"CRITICAL": 0, "WARNING": 1})
    return df.sort_values("_o", kind="stable").drop(columns="_o").reset_index(drop=True)


def visible_alerts(alerts, perms):
    return alerts[alerts["Category"].map(lambda c: ALERT_PERM[c] in perms)] if not alerts.empty else alerts


def alert_text(a):
    bar = "=" * 53
    return (f"{bar}\nMINING MONITORING ALERT\n{bar}\n[{a['Level']}]\n{ID_LABEL[a['Category']]}: {a['ID']}\n"
            f"Parameter: {a['Parameter']}\nValue: {a['Value']}\nStatus: {a['Status']}\nRecommended Action:\n {a['Action']}\n{bar}")


def maintenance_sets(d):
    eq, al = d["equipment"], d["alerts"]
    cnt = al[al["Category"].isin(["Equipment", "Maintenance"])]["ID"].value_counts() if not al.empty else pd.Series(dtype=int)
    eq = eq.assign(**{"Alert Count": eq["Equipment ID"].map(cnt).fillna(0).astype(int)})
    return eq, {
        "Due for maintenance": eq[mask(eq, is_due)],
        "Overdue": eq[mask(eq, is_overdue)],
        "Under maintenance": eq[eq["Maintenance Status"] == "Under maintenance"],
        "Excessive downtime": eq[eq["Downtime"] >= HIGH_DOWNTIME],
        "Repeated alerts": eq[eq["Alert Count"] >= 2],
        "Low availability": eq[eq["Availability"] < LOW_AVAIL],
    }


def priority_table(eq):
    def score(r):
        return ({"CRITICAL": 4, "WARNING": 2}.get(r["Alert Status"], 0) + (3 if is_overdue(r) else 1 if is_due(r) else 0)
                + (1 if r["Availability"] < LOW_AVAIL else 0) + (1 if r["Downtime"] >= HIGH_DOWNTIME else 0) + min(r["Alert Count"], 3))
    t = eq.assign(**{"Priority Score": [score(r) for _, r in eq.iterrows()]})
    cols = ["Equipment ID", "Equipment Type", "Alert Status", "Maintenance Status", "Availability", "Downtime", "Alert Count", "Priority Score"]
    return t[t["Priority Score"] > 0].sort_values("Priority Score", ascending=False)[cols]


def recommendations(d, perms):
    R, al = [], visible_alerts(d["alerts"], perms)
    for a in al[al["Level"] == "CRITICAL"].itertuples():
        R.append(f"[CRITICAL] {a.Category} {a.ID}: {a.Action}")
    if "Worker Safety" in perms:
        w = d["workers"]
        if w["PPE Compliance"].mean() < 90:
            R.append(f"Run PPE refresher briefings: average compliance is {w['PPE Compliance'].mean():.0f}%.")
        if (w["Fatigue"] >= FATIGUE_HIGH).any():
            R.append(f"Review rosters and rest periods for {int((w['Fatigue'] >= FATIGUE_HIGH).sum())} fatigued worker(s).")
        if (w["Training"] != "Complete").any():
            R.append(f"Complete outstanding safety training for {int((w['Training'] != 'Complete').sum())} worker(s).")
    if "Incidents" in perms and not d["incidents"].empty:
        sh = d["incidents"]["Shift"].value_counts()
        if sh.get("Night", 0) > sh.get("Day", 0):
            R.append("Night shift records more incidents than day shift: review supervision, lighting and fatigue controls.")
        if (d["incidents"]["Lost Time Injury"] == "Yes").any():
            R.append("Lost-time injuries recorded: confirm corrective actions are completed and verified.")
    if "Equipment" in perms:
        eq, sets = maintenance_sets(d)
        if len(sets["Overdue"]):
            R.append(f"Schedule overdue maintenance for: {', '.join(sets['Overdue']['Equipment ID'])}.")
        top = priority_table(eq).head(3)
        if len(top):
            R.append(f"Maintenance priority: {', '.join(top['Equipment ID'])}.")
    if not R:
        R.append("No corrective recommendations at this time. Continue routine monitoring.")
    return R


# ======================================================================================
# UI HELPERS
# ======================================================================================
def inject_styles():
    st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
    :root { --ink:#102329; --muted:#64777a; --teal:#0d7770; --line:#dce5e3; }
    html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
    h1, h2, h3 { font-family: 'Space Grotesk', sans-serif; letter-spacing: 0; }
    [data-testid="stSidebar"] { background: #102f32; }
    [data-testid="stSidebar"] * { color: #e9f4ed !important; }
    [data-testid="stSidebar"] .stButton button { background:#1d4a4d; border:1px solid #3a6a6d; }
    .brand { padding: 1rem 0 1.2rem; border-bottom: 1px solid #315659; margin-bottom: 1rem; }
    .brand-mark { display:inline-flex; align-items:center; justify-content:center; width:38px; height:38px; border-radius:10px; background:#b9e6bd; color:#102f32 !important; font-family:'Space Grotesk'; font-weight:700; margin-right:9px; }
    .brand-title { font-family:'Space Grotesk'; font-size:1.3rem; font-weight:700; vertical-align:middle; }
    .eyebrow { color: var(--teal); text-transform:uppercase; letter-spacing:.13em; font-size:.72rem; font-weight:700; }
    .hero { padding: 1rem 0 .5rem; }
    .hero h1 { font-size:2.1rem; margin:.15rem 0 .35rem; }
    .hero p { color:var(--muted); margin:0; }
    .metric { background:#fff; border:1px solid var(--line); border-radius:8px; padding:.9rem 1rem; min-height:100px; margin-bottom:.6rem; }
    .metric-label { color:var(--muted); font-size:.76rem; text-transform:uppercase; letter-spacing:.05em; }
    .metric-value { font-family:'Space Grotesk'; font-size:1.7rem; font-weight:700; margin-top:.3rem; color:var(--ink); }
    .metric-note { font-size:.75rem; color:var(--teal); margin-top:.15rem; }
    .stButton button, .stDownloadButton button { border-radius:6px; font-weight:600; }
    </style>""", unsafe_allow_html=True)


def metric(label, value, note=""):
    e = lambda x: html.escape(str(x))
    st.markdown(f'<div class="metric"><div class="metric-label">{e(label)}</div><div class="metric-value">{e(value)}</div>'
                f'<div class="metric-note">{e(note)}</div></div>', unsafe_allow_html=True)


def metric_row(items, per_row=4):
    for i in range(0, len(items), per_row):
        for col, item in zip(st.columns(per_row), items[i:i + per_row]):
            with col:
                metric(*item)


def page_header(kicker, title, description):
    e = html.escape
    st.markdown(f'<div class="hero"><div class="eyebrow">{e(kicker)}</div><h1>{e(title)}</h1><p>{e(description)}</p></div>', unsafe_allow_html=True)


def flash(msg, level="success"):
    st.session_state.setdefault("_flash", []).append((level, msg))


def show_flash():
    for level, msg in st.session_state.pop("_flash", []):
        getattr(st, level)(msg)


def pick(label, options):
    """Select from a list, or type a new value."""
    sel = st.selectbox(label, options)
    other = st.text_input(f"Other {label.lower()} (optional)")
    return other.strip() or sel


def has(df, msg="No data available yet."):
    if df.empty:
        st.info(msg)
    return not df.empty


def bar(df, x, y, color=None, cmap=None, height=320):
    fig = px.bar(df, x=x, y=y, color=color, color_discrete_map=cmap)
    fig.update_layout(height=height, margin=dict(l=0, r=0, t=20, b=0))
    st.plotly_chart(fig, use_container_width=True)


def search(df, q):
    if not q:
        return df
    return df[df.astype(str).apply(lambda c: c.str.contains(q, case=False, na=False, regex=False)).any(axis=1)]


def status_updater(key, id_col, status_col, options, label, df):
    if df.empty:
        return
    with st.expander(f"Update {label.lower()} status"):
        with st.form(f"upd_{key}"):
            ident = st.selectbox(f"{label} ID", df[id_col].tolist())
            new = st.selectbox("New status", options)
            go = st.form_submit_button("Update status")
        if go:
            update_cells(key, id_col, ident, {status_col: new})
            flash(f"{label} {ident} updated to '{new}'.")
            st.rerun()


# ======================================================================================
# PAGES
# ======================================================================================
def dashboard(d, perms):
    page_header("Control room / live overview", "Good decisions start with visible risk.", "A consolidated picture of safety, equipment and maintenance for your role.")
    w, inc, eq, rk = d["workers"], d["incidents"], d["equipment"], d["risk"]
    k = []
    if "Worker Safety" in perms:
        ppe = w["PPE Compliance"].mean()
        k += [("Total workers", len(w), "registered"), ("Near misses", int(w["Near Misses"].sum()), "worker records"),
              ("PPE compliance", f"{ppe:.0f}%" if pd.notna(ppe) else "n/a", "average across workers")]
    if "Incidents" in perms:
        k += [("Safety incidents", len(inc), "all recorded"), ("Open incidents", int((inc["Corrective Action Status"] != "Closed").sum()), "need follow-up")]
    if "Risk Assessment" in perms:
        k += [("High-risk observations", int((rk["Risk Level"].isin(["High", "Critical"]) & (rk["Status"] != "Closed")).sum()), "open High/Critical")]
    if "Equipment" in perms:
        avg = eq["Availability"].mean()
        k += [("Total equipment", len(eq), "monitored assets"),
              ("Equipment available", int((eq["Maintenance Status"] != "Under maintenance").sum()), "not under maintenance"),
              ("Under maintenance", int((eq["Maintenance Status"] == "Under maintenance").sum()), "currently offline"),
              ("Equipment alerts", int((eq["Alert Status"] != "NORMAL").sum()), "warning or critical"),
              ("Average availability", f"{avg:.1f}%" if pd.notna(avg) else "n/a", "monitored fleet"),
              ("Critical equipment alerts", int((eq["Alert Status"] == "CRITICAL").sum()), "inspect now")]
    metric_row(k)
    st.subheader("Active alerts")
    al = visible_alerts(d["alerts"], perms)
    if al.empty:
        st.success("No active alerts for your areas.")
    else:
        st.dataframe(al[["Level", "Category", "ID", "Parameter", "Value", "Status"]], use_container_width=True, hide_index=True)
        with st.expander("View alert notices (standard format)"):
            for _, a in al.head(10).iterrows():
                st.code(alert_text(a), language=None)
    figs = []
    if "Incidents" in perms and not inc.empty:
        figs.append(("Incidents by severity", counts(inc["Severity"], "Severity"), "Severity", SEV_COLORS))
    if "Equipment" in perms and not eq.empty:
        figs.append(("Equipment condition", counts(eq["Alert Status"], "Status"), "Status", STATUS_COLORS))
    if "Worker Safety" in perms and not w.empty:
        figs.append(("Worker risk levels", counts(w["Risk Level"], "Risk Level"), "Risk Level", SEV_COLORS))
    if figs:
        for col, (title, df, x, cmap) in zip(st.columns(len(figs)), figs):
            with col:
                st.markdown(f"**{title}**")
                bar(df, x, "Count", color=x, cmap=cmap, height=260)
    st.info("Prototype notice: thresholds and risk indicators are educational examples only, not manufacturer or mine safety limits.")


def worker_page(d):
    page_header("People / worker safety", "Worker safety data", "Record worker safety information and spot fatigue, training gaps and PPE drift early.")
    w = d["workers"]
    ppe = w["PPE Compliance"].mean()
    metric_row([("PPE compliance", f"{ppe:.0f}%" if pd.notna(ppe) else "n/a", "average across workers"),
                ("Training current", f"{(w['Training'] == 'Complete').mean():.0%}" if len(w) else "n/a", "completion rate"),
                ("Fatigue watch", int((w["Fatigue"] >= FATIGUE_HIGH).sum()), "level 4 or higher"),
                ("High-risk workers", int(w["Risk Level"].isin(["High", "Critical"]).sum()), "needs follow-up")])
    with st.expander("➕ Add worker safety record"):
        with st.form("add_worker_form", clear_on_submit=True):
            c1, c2 = st.columns(2)
            with c1:
                worker_id = st.text_input("Worker ID *")
                name = st.text_input("Worker name *")
                department = pick("Department", merged(DEFAULT_DEPTS, w["Department"], d["incidents"]["Department"]))
                job_role = st.text_input("Job role")
                shift = st.selectbox("Shift", ["Day", "Night"])
            with c2:
                ppe_in = st.slider("PPE compliance (%)", 0, 100, 100)
                training = st.selectbox("Safety training status", ["Complete", "Due", "Expired"])
                fatigue = st.slider("Fatigue level (1 = rested, 5 = exhausted)", 1, 5, 2)
                near = st.number_input("Near misses", min_value=0, value=0, step=1)
                prev = st.number_input("Previous incidents", min_value=0, value=0, step=1)
            obs = st.text_area("Safety observations")
            save = st.form_submit_button("Save worker record", type="primary")
        if save:
            if not valid_id(worker_id) or not name.strip():
                st.error(f"Worker ID and name are required. {ID_HELP}")
            elif id_exists(w, "Worker ID", worker_id):
                st.error("That Worker ID already exists.")
            else:
                rec = {"Worker ID": worker_id.strip(), "Name": name.strip(), "Department": department, "Job Role": job_role.strip(),
                       "Shift": shift, "PPE Compliance": ppe_in, "Training": training, "Fatigue": fatigue,
                       "Safety Observations": obs.strip(), "Near Misses": near, "Previous Incidents": prev}
                rec["Risk Level"] = worker_risk_level(rec)
                append_row("workers", rec)
                flash(f"Worker {rec['Worker ID']} saved. Risk level: {rec['Risk Level']}.")
                warns = worker_warnings(rec)
                if warns:
                    flash("Unsafe conditions identified: " + "; ".join(warns) + ".", "warning")
                st.rerun()
    st.divider()
    if not has(w, "No worker records yet. Use the form above to add one."):
        return
    c1, c2 = st.columns(2)
    depts = sorted(w["Department"].unique())
    sel = c1.multiselect("Filter departments", depts, default=depts, key="w_dept")
    q = c2.text_input("Search workers", key="w_q")
    view = search(w[w["Department"].isin(sel)], q)
    st.dataframe(view, use_container_width=True, hide_index=True,
                 column_config={"PPE Compliance": st.column_config.ProgressColumn("PPE Compliance", min_value=0, max_value=100, format="%d%%")})
    flagged = [{"Worker ID": r["Worker ID"], "Name": r["Name"], "Warnings": "; ".join(ws)} for _, r in view.iterrows() if (ws := worker_warnings(r))]
    if flagged:
        st.warning(f"{len(flagged)} worker record(s) need a safety follow-up.")
        st.dataframe(pd.DataFrame(flagged), use_container_width=True, hide_index=True)
    st.download_button("Download worker data (CSV)", view.to_csv(index=False).encode("utf-8"), "workers.csv", "text/csv")


def valid_id(v):
    return bool(ID_RE.match(v.strip()))


def incidents_page(d):
    page_header("Safety / incident register", "Incident database", "Add, search, filter, categorise and analyse the events shaping your safety priorities.")
    inc = d["incidents"]
    with st.expander("➕ Add new incident"):
        with st.form("add_incident_form", clear_on_submit=True):
            c1, c2 = st.columns(2)
            with c1:
                incident_id = st.text_input("Incident ID *")
                inc_date = st.date_input("Incident date", value=date.today(), max_value=date.today())
                inc_time = st.time_input("Incident time")
                shift = st.selectbox("Shift", ["Day", "Night"])
                location = st.text_input("Location *")
                department = pick("Department", merged(DEFAULT_DEPTS, inc["Department"], d["workers"]["Department"]))
            with c2:
                itype = pick("Incident type", merged(INCIDENT_TYPES, inc["Incident Type"]))
                severity = st.selectbox("Severity", ["Low", "Medium", "High", "Critical"])
                injury = st.selectbox("Injury status", ["No injury", "First aid", "Medical treatment", "Fatality"])
                lti = st.selectbox("Lost-time injury", ["No", "Yes"])
                cause = st.text_input("Cause")
                status = st.selectbox("Incident status", ["Open", "Under Investigation", "Closed"])
            action = st.text_area("Corrective action")
            save = st.form_submit_button("Save incident", type="primary")
        if save:
            if not valid_id(incident_id) or not location.strip():
                st.error(f"Incident ID and location are required. {ID_HELP}")
            elif id_exists(inc, "Incident ID", incident_id):
                st.error("That Incident ID already exists.")
            else:
                append_row("incidents", {"Incident ID": incident_id.strip(), "Date": str(inc_date), "Time": inc_time.strftime("%H:%M"),
                                         "Shift": shift, "Location": location.strip(), "Department": department, "Incident Type": itype,
                                         "Severity": severity, "Injury Status": injury, "Lost Time Injury": lti, "Cause": cause.strip(),
                                         "Corrective Action": action.strip(), "Corrective Action Status": status})
                flash(f"Incident {incident_id.strip()} saved.")
                if severity == "Critical":
                    flash("CRITICAL incident recorded: notify management and begin the investigation immediately.", "error")
                st.rerun()
    status_updater("incidents", "Incident ID", "Corrective Action Status", ["Open", "Under Investigation", "Closed"], "Incident", inc)
    st.divider()
    if not has(inc, "No incidents recorded yet."):
        return
    inc = inc.assign(_d=pd.to_datetime(inc["Date"], errors="coerce"))
    c1, c2, c3 = st.columns(3)
    q = c1.text_input("Search incident records", placeholder="location, cause, type, department", key="i_q")
    sev_opts = sorted(inc["Severity"].unique())
    sev = c2.multiselect("Severity", sev_opts, default=sev_opts, key="i_sev")
    dept_opts = sorted(inc["Department"].unique())
    dept = c3.multiselect("Department", dept_opts, default=dept_opts, key="i_dept")
    c4, c5, c6 = st.columns(3)
    shift_opts = sorted(inc["Shift"].unique())
    shifts = c4.multiselect("Shift", shift_opts, default=shift_opts, key="i_shift")
    stat_opts = sorted(inc["Corrective Action Status"].unique())
    stats = c5.multiselect("Status", stat_opts, default=stat_opts, key="i_stat")
    view = inc[inc["Severity"].isin(sev) & inc["Department"].isin(dept) & inc["Shift"].isin(shifts) & inc["Corrective Action Status"].isin(stats)]
    if inc["_d"].notna().any():
        p = c6.date_input("Period", (inc["_d"].min().date(), inc["_d"].max().date()), key="i_period")
        if len(p) == 2:
            view = view[view["_d"].isna() | ((view["_d"].dt.date >= p[0]) & (view["_d"].dt.date <= p[1]))]
    view = search(view, q).drop(columns="_d")
    metric_row([("Matching incidents", len(view), "current filters"),
                ("High / critical", int(view["Severity"].isin(["High", "Critical"]).sum()), "priority review"),
                ("Night shift", int((view["Shift"] == "Night").sum()), "of matching incidents"),
                ("Lost-time injuries", int((view["Lost Time Injury"] == "Yes").sum()), "of matching incidents")])
    st.dataframe(view, use_container_width=True, hide_index=True)
    st.download_button("Download filtered incidents (CSV)", view.to_csv(index=False).encode("utf-8"), "incidents.csv", "text/csv")
    if view.empty:
        return
    a, b = st.columns(2)
    with a:
        st.subheader("By department")
        bar(counts(view["Department"], "Department"), "Department", "Count", color="Department")
    with b:
        st.subheader("By incident type")
        bar(counts(view["Incident Type"], "Incident type"), "Incident type", "Count", color="Incident type")
    st.subheader("Incident trend by month")
    dates = pd.to_datetime(view["Date"], errors="coerce").dropna()
    if not dates.empty:
        trend = counts(dates.dt.to_period("M").astype(str), "Month").sort_values("Month")
        fig = px.line(trend, x="Month", y="Count", markers=True)
        fig.update_layout(height=280, margin=dict(l=0, r=0, t=10, b=0))
        st.plotly_chart(fig, use_container_width=True)


def equipment_page(d):
    page_header("Assets / condition monitoring", "Equipment health", "Register equipment and monitor condition against prototype thresholds.")
    eq = d["equipment"]
    with st.expander("➕ Add equipment"):
        with st.form("add_equipment_form", clear_on_submit=True):
            c1, c2, c3 = st.columns(3)
            with c1:
                equipment_id = st.text_input("Equipment ID *")
                etype = pick("Equipment type", merged(EQUIPMENT_TYPES, eq["Equipment Type"]))
                manufacturer = st.text_input("Manufacturer")
                location = st.text_input("Location")
                op_hours = st.number_input("Operating hours *", min_value=0.0, value=0.0, step=10.0)
            with c2:
                temperature = st.number_input("Temperature (°C)", min_value=0.0, max_value=500.0, value=25.0)
                vibration = st.number_input("Vibration (mm/s)", min_value=0.0, max_value=100.0, value=0.0)
                fuel = st.number_input("Fuel consumption (L/h)", min_value=0.0, value=0.0)
                downtime = st.number_input("Downtime (hours)", min_value=0.0, value=0.0, step=1.0)
            with c3:
                brake = st.selectbox("Brake status", ["Good", "Fair", "Poor"])
                tyre = st.selectbox("Tyre status", ["Good", "Fair", "Poor"])
                engine = st.selectbox("Engine status", ["Good", "Fair", "Poor"])
                mstatus = st.selectbox("Maintenance status", ["Up to date", "Scheduled", "Due", "Overdue", "Under maintenance"])
                last_m = st.date_input("Last maintenance", value=date.today())
                next_m = st.date_input("Next maintenance", value=date.today() + timedelta(days=30))
            st.caption("Availability is calculated: Operating time / (Operating time + Downtime) × 100.")
            save = st.form_submit_button("Save equipment", type="primary")
        if save:
            if not valid_id(equipment_id):
                st.error(f"Equipment ID is required. {ID_HELP}")
            elif id_exists(eq, "Equipment ID", equipment_id):
                st.error("That Equipment ID already exists.")
            elif op_hours + downtime <= 0:
                st.error("Enter operating hours or downtime so availability can be calculated.")
            elif next_m < last_m:
                st.error("Next maintenance date cannot be before the last maintenance date.")
            else:
                rec = {"Equipment ID": equipment_id.strip(), "Equipment Type": etype, "Manufacturer": manufacturer.strip(),
                       "Location": location.strip(), "Operating Hours": op_hours, "Temperature": temperature, "Vibration": vibration,
                       "Fuel Consumption": fuel, "Brake Status": brake, "Tyre Status": tyre, "Engine Status": engine,
                       "Maintenance Status": mstatus, "Downtime": downtime, "Availability": availability(op_hours, downtime),
                       "Last Maintenance": str(last_m), "Next Maintenance": str(next_m)}
                append_row("equipment", rec)
                flash(f"Equipment {rec['Equipment ID']} saved. Availability: {rec['Availability']}%.")
                st_ = equipment_status(rec)
                if st_ != "NORMAL":
                    flash(f"{rec['Equipment ID']}: {equipment_message(rec)}", "error" if st_ == "CRITICAL" else "warning")
                st.rerun()
    if not eq.empty:
        with st.expander("Update maintenance status / dates"):
            with st.form("upd_equipment_maint"):
                ident = st.selectbox("Equipment ID", eq["Equipment ID"].tolist())
                new = st.selectbox("Maintenance status", ["Up to date", "Scheduled", "Due", "Overdue", "Under maintenance"])
                lm = st.date_input("Last maintenance", value=date.today(), key="um_last")
                nm = st.date_input("Next maintenance", value=date.today() + timedelta(days=30), key="um_next")
                go = st.form_submit_button("Update")
            if go:
                if nm < lm:
                    st.error("Next maintenance date cannot be before the last maintenance date.")
                else:
                    update_cells("equipment", "Equipment ID", ident, {"Maintenance Status": new, "Last Maintenance": str(lm), "Next Maintenance": str(nm)})
                    flash(f"Maintenance details for {ident} updated.")
                    st.rerun()
    st.caption(f"Educational thresholds only: NORMAL < {TEMP_WARN} °C and < {VIB_WARN} mm/s; WARNING {TEMP_WARN}-{TEMP_CRIT} °C or {VIB_WARN}-{VIB_CRIT} mm/s; "
               f"CRITICAL > {TEMP_CRIT} °C or > {VIB_CRIT} mm/s. Confirm real limits with approved site procedures.")
    st.divider()
    if not has(eq, "No equipment registered yet."):
        return
    c1, c2 = st.columns(2)
    sf = c1.multiselect("Alert status", ["NORMAL", "WARNING", "CRITICAL"], default=["NORMAL", "WARNING", "CRITICAL"], key="e_stat")
    types = sorted(eq["Equipment Type"].unique())
    tf = c2.multiselect("Equipment type", types, default=types, key="e_type")
    view = eq[eq["Alert Status"].isin(sf) & eq["Equipment Type"].isin(tf)]
    view = view.assign(Condition=[equipment_message(r) for _, r in view.iterrows()])
    st.dataframe(view, use_container_width=True, hide_index=True,
                 column_config={"Availability": st.column_config.ProgressColumn("Availability", min_value=0, max_value=100, format="%d%%")})
    for _, r in view[view["Alert Status"] != "NORMAL"].iterrows():
        (st.error if r["Alert Status"] == "CRITICAL" else st.warning)(f"{r['Equipment ID']}: {equipment_message(r)}")
    st.download_button("Download equipment data (CSV)", view.drop(columns="Condition").to_csv(index=False).encode("utf-8"), "equipment.csv", "text/csv")


def maintenance_page(d):
    page_header("Assets / maintenance planning", "Maintenance control", "Identify equipment that needs maintenance and track work orders.")
    eq, sets = maintenance_sets(d)
    mt = d["maintenance"]
    tab1, tab2 = st.tabs(["Maintenance monitoring", "Work orders"])
    with tab1:
        st.caption(f"Prototype rules: due = within {DUE_SOON_DAYS} days or marked Due; excessive downtime >= {HIGH_DOWNTIME} h; low availability < {LOW_AVAIL}%; "
                   "repeated alerts = 2 or more active alerts on the same equipment.")
        avg = eq["Availability"].mean()
        metric_row([("Average availability", f"{avg:.1f}%" if pd.notna(avg) else "n/a", "monitored fleet")] +
                   [(name, len(df), "equipment") for name, df in list(sets.items())[:3]])
        metric_row([(name, len(df), "equipment") for name, df in list(sets.items())[3:]], per_row=3)
        cols = ["Equipment ID", "Equipment Type", "Maintenance Status", "Next Maintenance", "Downtime", "Availability", "Alert Status", "Alert Count"]
        for tab, (name, df) in zip(st.tabs([f"{n} ({len(df)})" for n, df in sets.items()]), sets.items()):
            with tab:
                if df.empty:
                    st.success(f"No equipment in category: {name}.")
                else:
                    st.dataframe(df[cols], use_container_width=True, hide_index=True)
        st.subheader("Maintenance priority ranking")
        pt = priority_table(eq)
        if has(pt, "No equipment currently needs maintenance priority."):
            st.dataframe(pt, use_container_width=True, hide_index=True)
    with tab2:
        with st.expander("➕ Add maintenance work order", expanded=mt.empty):
            with st.form("add_maintenance_form", clear_on_submit=True):
                c1, c2 = st.columns(2)
                with c1:
                    work_id = st.text_input("Work order ID *")
                    equipment_id = st.selectbox("Equipment", ["Not linked"] + eq["Equipment ID"].tolist())
                    task = st.text_input("Maintenance task *")
                    assigned = st.text_input("Assigned to")
                    priority = st.selectbox("Priority", ["Low", "Medium", "High", "Urgent"])
                with c2:
                    status = st.selectbox("Status", ["Planned", "In progress", "On hold", "Completed", "Overdue"])
                    scheduled = st.date_input("Scheduled date", value=date.today())
                    completed = st.date_input("Completed date (used only if Completed)", value=date.today())
                    downtime = st.number_input("Downtime (hours)", min_value=0.0, value=0.0, step=1.0)
                notes = st.text_area("Notes / parts required / work performed")
                save = st.form_submit_button("Save work order", type="primary")
            if save:
                if not valid_id(work_id) or not task.strip():
                    st.error(f"Work order ID and task are required. {ID_HELP}")
                elif id_exists(mt, "Work Order ID", work_id):
                    st.error("That work order ID already exists.")
                elif status == "Completed" and completed < scheduled:
                    st.error("Completed date cannot be before the scheduled date.")
                else:
                    append_row("maintenance", {"Work Order ID": work_id.strip(), "Equipment ID": "" if equipment_id == "Not linked" else equipment_id,
                                               "Task": task.strip(), "Assigned To": assigned.strip(), "Priority": priority, "Status": status,
                                               "Scheduled Date": str(scheduled), "Completed Date": str(completed) if status == "Completed" else "",
                                               "Downtime (hours)": downtime, "Notes": notes.strip()})
                    flash(f"Work order {work_id.strip()} saved.")
                    st.rerun()
        status_updater("maintenance", "Work Order ID", "Status", ["Planned", "In progress", "On hold", "Completed", "Overdue"], "Work order", mt)
        if has(mt, "No work orders yet. Use the form above to add one."):
            st.dataframe(mt, use_container_width=True, hide_index=True)
            st.download_button("Download work orders (CSV)", mt.to_csv(index=False).encode("utf-8"), "maintenance.csv", "text/csv")


def risk_page(d):
    page_header("Safety / risk register", "Risk assessment", "Record hazards, score the risk and document controls and review dates.")
    rk = d["risk"]
    open_hi = rk[rk["Risk Level"].isin(["High", "Critical"]) & (rk["Status"] != "Closed")]
    if not open_hi.empty:
        st.warning(f"{len(open_hi)} open High/Critical risk assessment(s): review controls with responsible safety personnel.")
    st.caption("Risk score = Likelihood × Consequence (1-5 scale). Prototype bands: Low 1-4, Medium 5-9, High 10-16, Critical 17-25. Follow your site's approved risk matrix.")
    with st.expander("Risk matrix reference"):
        mat = pd.DataFrame([[l * c for c in range(1, 6)] for l in range(5, 0, -1)], index=[f"Likelihood {l}" for l in range(5, 0, -1)],
                           columns=[f"Consequence {c}" for c in range(1, 6)])
        st.dataframe(mat, use_container_width=True)
    with st.expander("➕ New risk assessment", expanded=rk.empty):
        with st.form("risk_form", clear_on_submit=True):
            c1, c2 = st.columns(2)
            with c1:
                aid = st.text_input("Assessment ID *")
                adate = st.date_input("Assessment date", value=date.today())
                location = st.text_input("Location / work area")
                department = pick("Department", merged(DEFAULT_DEPTS, d["workers"]["Department"], d["incidents"]["Department"]))
                hazard = st.text_input("Hazard or observation *")
                people = st.text_input("People exposed / at risk")
                by = st.text_input("Assessed by")
            with c2:
                likelihood = st.slider("Likelihood (1-5)", 1, 5, 3)
                consequence = st.slider("Consequence (1-5)", 1, 5, 3)
                existing = st.text_area("Existing controls")
                additional = st.text_area("Additional controls / actions required")
                review = st.date_input("Review date", value=date.today() + timedelta(days=30))
                status = st.selectbox("Status", ["Open", "Controls in progress", "Reviewed", "Closed"])
            save = st.form_submit_button("Calculate and save assessment", type="primary")
        if save:
            if not valid_id(aid) or not hazard.strip():
                st.error(f"Assessment ID and hazard are required. {ID_HELP}")
            elif id_exists(rk, "Assessment ID", aid):
                st.error("That Assessment ID already exists.")
            elif review < adate:
                st.error("Review date cannot be before the assessment date.")
            else:
                score = likelihood * consequence
                level = classify_risk(score)
                append_row("risk", {"Assessment ID": aid.strip(), "Date": str(adate), "Location": location.strip(), "Department": department,
                                    "Hazard": hazard.strip(), "People at Risk": people.strip(), "Existing Controls": existing.strip(),
                                    "Likelihood": likelihood, "Consequence": consequence, "Risk Score": score, "Risk Level": level,
                                    "Additional Controls": additional.strip(), "Assessed By": by.strip(), "Review Date": str(review), "Status": status})
                flash(f"Assessment {aid.strip()} saved: {level} risk (score {score}).")
                if level in ("High", "Critical"):
                    flash(f"{level.upper()} RISK identified: promptly review controls with responsible site safety personnel.", "error" if level == "Critical" else "warning")
                st.rerun()
    status_updater("risk", "Assessment ID", "Status", ["Open", "Controls in progress", "Reviewed", "Closed"], "Assessment", rk)
    st.subheader("Saved risk assessments")
    if has(rk, "No risk assessments saved yet. Complete the form above to create one."):
        levels = ["Low", "Medium", "High", "Critical"]
        sel = st.multiselect("Filter by risk level", levels, default=levels, key="r_lvl")
        view = rk[rk["Risk Level"].isin(sel)]
        st.dataframe(view, use_container_width=True, hide_index=True)
        st.download_button("Download risk assessments (CSV)", view.to_csv(index=False).encode("utf-8"), "risk_assessments.csv", "text/csv")
        st.subheader("Assessments by risk level")
        bar(counts(rk["Risk Level"], "Risk Level"), "Risk Level", "Count", color="Risk Level", cmap=SEV_COLORS, height=260)


# ---------------------------------------------------------------- analytics
QUESTIONS = []


def question(group, text, needs):
    def deco(fn):
        QUESTIONS.append((group, text, set(needs), fn))
        return fn
    return deco


HS, EQ, IN = "Health & Safety", "Equipment", "Integrated"


@question(HS, "How many safety incidents occurred during the selected period?", {"Incidents"})
def q1(d, perms):
    inc = d["incidents"].assign(_d=pd.to_datetime(d["incidents"]["Date"], errors="coerce"))
    if inc["_d"].notna().any():
        p = st.date_input("Select period", (inc["_d"].min().date(), inc["_d"].max().date()), key="q_period")
        if len(p) == 2:
            inc = inc[(inc["_d"].dt.date >= p[0]) & (inc["_d"].dt.date <= p[1])]
    st.metric("Incidents in period", len(inc))
    if has(inc):
        bar(counts(inc["Severity"], "Severity"), "Severity", "Count", color="Severity", cmap=SEV_COLORS)


@question(HS, "Which department has the highest number of incidents?", {"Incidents"})
def q2(d, perms):
    c = counts(d["incidents"]["Department"], "Department")
    if has(c):
        st.metric("Top department", c.iloc[0]["Department"], f"{c.iloc[0]['Count']} incident(s)")
        bar(c, "Department", "Count", color="Department")


@question(HS, "Which shift records the most incidents? Is there a day / night difference?", {"Incidents"})
def q3(d, perms):
    c = counts(d["incidents"]["Shift"], "Shift")
    if has(c):
        s = d["incidents"]["Shift"].value_counts()
        st.metric("Night vs day", f"{s.get('Night', 0)} vs {s.get('Day', 0)}", "incidents")
        bar(c, "Shift", "Count", color="Shift")


@question(HS, "What percentage of workers comply with PPE requirements?", {"Worker Safety"})
def q4(d, perms):
    w = d["workers"]
    if has(w):
        ok = (w["PPE Compliance"] >= PPE_MIN).mean()
        st.metric(f"Workers at or above {PPE_MIN}% PPE compliance", f"{ok:.0%}", f"average compliance {w['PPE Compliance'].mean():.0f}%")
        bar(w.groupby("Department", as_index=False)["PPE Compliance"].mean(), "Department", "PPE Compliance", color="Department")


@question(HS, "How many near misses have been recorded?", {"Worker Safety"})
def q5(d, perms):
    w = d["workers"]
    st.metric("Near misses (worker records)", int(w["Near Misses"].sum()))
    if has(w):
        bar(w.groupby("Department", as_index=False)["Near Misses"].sum(), "Department", "Near Misses", color="Department")


@question(HS, "Which incident types occur most frequently?", {"Incidents"})
def q6(d, perms):
    c = counts(d["incidents"]["Incident Type"], "Incident type")
    if has(c):
        bar(c, "Incident type", "Count", color="Incident type")


@question(HS, "How many incidents are classified as high or critical?", {"Incidents"})
def q7(d, perms):
    inc = d["incidents"]
    hc = inc[inc["Severity"].isin(["High", "Critical"])]
    st.metric("High / critical incidents", len(hc), f"{len(hc) / len(inc):.0%} of all incidents" if len(inc) else "")
    if has(hc):
        st.dataframe(hc, use_container_width=True, hide_index=True)


@question(HS, "Which departments have the highest safety risk?", {"Worker Safety", "Incidents"})
def q8(d, perms):
    w, inc = d["workers"], d["incidents"]
    a = counts(w[w["Risk Level"].isin(["High", "Critical"])]["Department"], "Department").rename(columns={"Count": "High-risk workers"})
    b = counts(inc[inc["Severity"].isin(["High", "Critical"])]["Department"], "Department").rename(columns={"Count": "High/critical incidents"})
    t = pd.merge(a, b, on="Department", how="outer").fillna(0)
    if has(t, "No high-risk workers or incidents recorded."):
        t["Risk points"] = t["High-risk workers"] + t["High/critical incidents"]
        t = t.sort_values("Risk points", ascending=False)
        st.dataframe(t, use_container_width=True, hide_index=True)
        bar(t, "Department", "Risk points", color="Department")


@question(HS, "Which safety conditions require immediate attention?", {"Dashboard"})
def q9(d, perms):
    al = visible_alerts(d["alerts"], perms)
    al = al[al["Category"].isin(["Worker", "Incident", "Risk"])]
    if has(al, "No safety conditions currently need immediate attention."):
        st.dataframe(al[["Level", "Category", "ID", "Parameter", "Value", "Status", "Action"]], use_container_width=True, hide_index=True)


def _eq_rank(d, col, label, ascending=False, unit=""):
    eq = d["equipment"]
    if has(eq):
        t = eq.sort_values(col, ascending=ascending)[["Equipment ID", "Equipment Type", col]]
        st.metric(label, t.iloc[0]["Equipment ID"], f"{t.iloc[0][col]}{unit}")
        bar(t, "Equipment ID", col, color="Equipment ID")


@question(EQ, "Which equipment has the highest downtime?", {"Equipment"})
def q10(d, perms):
    _eq_rank(d, "Downtime", "Highest downtime", unit=" h")


@question(EQ, "Which equipment has the lowest availability?", {"Equipment"})
def q11(d, perms):
    _eq_rank(d, "Availability", "Lowest availability", ascending=True, unit="%")


@question(EQ, "Which equipment has the highest vibration?", {"Equipment"})
def q12(d, perms):
    _eq_rank(d, "Vibration", "Highest vibration", unit=" mm/s")


@question(EQ, "Which equipment has the highest operating temperature?", {"Equipment"})
def q13(d, perms):
    _eq_rank(d, "Temperature", "Highest temperature", unit=" °C")


@question(EQ, "Which equipment has generated the most alerts?", {"Equipment"})
def q14(d, perms):
    eq, _ = maintenance_sets(d)
    t = eq[eq["Alert Count"] > 0].sort_values("Alert Count", ascending=False)[["Equipment ID", "Equipment Type", "Alert Count"]]
    if has(t, "No equipment alerts are active."):
        st.dataframe(t, use_container_width=True, hide_index=True)
        bar(t, "Equipment ID", "Alert Count", color="Equipment ID")


@question(EQ, "Which equipment requires maintenance?", {"Equipment"})
def q15(d, perms):
    _, sets = maintenance_sets(d)
    t = pd.concat([sets["Due for maintenance"], sets["Overdue"], sets["Under maintenance"]]).drop_duplicates("Equipment ID")
    if has(t, "No equipment currently requires maintenance."):
        st.dataframe(t[["Equipment ID", "Equipment Type", "Maintenance Status", "Next Maintenance", "Availability"]], use_container_width=True, hide_index=True)


@question(EQ, "Which equipment is overdue for maintenance?", {"Equipment"})
def q16(d, perms):
    _, sets = maintenance_sets(d)
    t = sets["Overdue"]
    if has(t, "No equipment is overdue for maintenance."):
        st.dataframe(t[["Equipment ID", "Equipment Type", "Maintenance Status", "Next Maintenance"]], use_container_width=True, hide_index=True)


@question(EQ, "What is the average equipment availability?", {"Equipment"})
def q17(d, perms):
    eq = d["equipment"]
    if has(eq):
        st.metric("Average availability", f"{eq['Availability'].mean():.1f}%")
        bar(eq.groupby("Equipment Type", as_index=False)["Availability"].mean(), "Equipment Type", "Availability", color="Equipment Type")


@question(EQ, "Which equipment type has the highest downtime?", {"Equipment"})
def q18(d, perms):
    eq = d["equipment"]
    if has(eq):
        t = eq.groupby("Equipment Type", as_index=False)["Downtime"].sum().sort_values("Downtime", ascending=False)
        st.metric("Highest downtime type", t.iloc[0]["Equipment Type"], f"{t.iloc[0]['Downtime']:.0f} h")
        bar(t, "Equipment Type", "Downtime", color="Equipment Type")


@question(EQ, "Which equipment requires immediate inspection?", {"Equipment"})
def q19(d, perms):
    eq = d["equipment"]
    t = eq[eq["Alert Status"] == "CRITICAL"]
    if has(t, "No equipment is currently in a critical state."):
        for _, r in t.iterrows():
            st.error(f"{r['Equipment ID']}: {equipment_message(r)}")


@question(EQ, "What percentage of monitored equipment is operating normally?", {"Equipment"})
def q20(d, perms):
    eq = d["equipment"]
    if has(eq):
        st.metric("Operating normally", f"{(eq['Alert Status'] == 'NORMAL').mean():.0%}")
        bar(counts(eq["Alert Status"], "Status"), "Status", "Count", color="Status", cmap=STATUS_COLORS)


@question(EQ, "Which equipment should receive maintenance priority?", {"Equipment"})
def q21(d, perms):
    eq, _ = maintenance_sets(d)
    t = priority_table(eq)
    if has(t, "No equipment currently needs maintenance priority."):
        st.dataframe(t, use_container_width=True, hide_index=True)
        bar(t, "Equipment ID", "Priority Score", color="Equipment ID")


@question(IN, "What are the most common causes of safety incidents?", {"Incidents"})
def q22(d, perms):
    c = counts(d["incidents"]["Cause"].replace("", pd.NA).dropna(), "Cause")
    if has(c):
        bar(c, "Cause", "Count", color="Cause")


@question(IN, "Which safety indicators require management intervention?", {"Worker Safety", "Incidents"})
def q23(d, perms):
    w, inc = d["workers"], d["incidents"]
    rows = [("Average PPE compliance", f"{w['PPE Compliance'].mean():.0f}%", ">= 90%", w["PPE Compliance"].mean() < 90),
            ("Workers with high fatigue", int((w["Fatigue"] >= FATIGUE_HIGH).sum()), "0", (w["Fatigue"] >= FATIGUE_HIGH).any()),
            ("Workers with incomplete training", int((w["Training"] != "Complete").sum()), "0", (w["Training"] != "Complete").any()),
            ("Open critical incidents", int(((inc["Severity"] == "Critical") & (inc["Corrective Action Status"] != "Closed")).sum()), "0",
             ((inc["Severity"] == "Critical") & (inc["Corrective Action Status"] != "Closed")).any()),
            ("Lost-time injuries", int((inc["Lost Time Injury"] == "Yes").sum()), "0", (inc["Lost Time Injury"] == "Yes").any())]
    st.dataframe(pd.DataFrame([{"Indicator": a, "Value": b, "Target": c, "Status": "INTERVENE" if e else "OK"} for a, b, c, e in rows]),
                 use_container_width=True, hide_index=True)


@question(IN, "How many critical alerts are currently active?", {"Dashboard"})
def q24(d, perms):
    al = visible_alerts(d["alerts"], perms)
    st.metric("Active critical alerts", int((al["Level"] == "CRITICAL").sum()), f"{len(al)} alerts in total")
    if (al["Level"] == "CRITICAL").any():
        st.dataframe(al[al["Level"] == "CRITICAL"][["Category", "ID", "Parameter", "Value", "Status"]], use_container_width=True, hide_index=True)


@question(IN, "Which areas of the operation require the greatest attention?", {"Incidents", "Equipment"})
def q25(d, perms):
    inc, eq = d["incidents"], d["equipment"]
    a = counts(inc["Location"].replace("", pd.NA).dropna(), "Location").rename(columns={"Count": "Incidents"})
    b = counts(eq[eq["Alert Status"] != "NORMAL"]["Location"].replace("", pd.NA).dropna(), "Location").rename(columns={"Count": "Equipment alerts"})
    t = pd.merge(a, b, on="Location", how="outer").fillna(0)
    if has(t):
        t["Attention score"] = t["Incidents"] + 2 * t["Equipment alerts"]
        t = t.sort_values("Attention score", ascending=False)
        st.dataframe(t, use_container_width=True, hide_index=True)
        bar(t, "Location", "Attention score", color="Location")


@question(IN, "What recommendations can be generated from the monitoring results?", {"Dashboard"})
def q26(d, perms):
    for r in recommendations(d, perms):
        st.markdown(f"- {r}")


def analytics_page(d, perms):
    page_header("Insights / decision support", "Interactive analysis", "Answer practical mining engineering questions from the monitoring data.")
    avail = [q for q in QUESTIONS if q[2] <= perms]
    groups = list(dict.fromkeys(q[0] for q in avail))
    group = st.radio("Category", groups, horizontal=True)
    qs = [q for q in avail if q[0] == group]
    text = st.selectbox("Choose a question", [q[1] for q in qs])
    next(q for q in qs if q[1] == text)[3](d, perms)


# ---------------------------------------------------------------- reports
def build_report(d, perms, user):
    L = ["SafeTrak MINING Systems: HEALTH, SAFETY AND EQUIPMENT MONITORING REPORT", "=" * 64,
         f"Generated    : {datetime.now():%Y-%m-%d %H:%M}", f"Prepared for : {user['Name']} ({user['Role']})",
         "Note: thresholds are educational prototype values, not mine safety limits.", ""]
    n = [0]

    def sec(title):
        n[0] += 1
        L.extend(["", f"{n[0]}. {title}", "-" * 64])

    al = visible_alerts(d["alerts"], perms)
    sec("ACTIVE ALERTS")
    L.append(f"Critical: {(al['Level'] == 'CRITICAL').sum()}    Warning: {(al['Level'] == 'WARNING').sum()}")
    L += [f"[{a.Level}] {a.Category} {a.ID} | {a.Parameter}: {a.Value} | {a.Status}" for a in al.itertuples()]
    if "Worker Safety" in perms:
        w = d["workers"]
        sec("WORKER SAFETY")
        L += [f"Total workers          : {len(w)}", f"Average PPE compliance : {w['PPE Compliance'].mean():.0f}%",
              f"Workers >= {PPE_MIN}% PPE     : {(w['PPE Compliance'] >= PPE_MIN).mean():.0%}" if len(w) else "",
              f"High fatigue (>= {FATIGUE_HIGH})     : {int((w['Fatigue'] >= FATIGUE_HIGH).sum())}",
              f"Training incomplete    : {int((w['Training'] != 'Complete').sum())}", f"Near misses            : {int(w['Near Misses'].sum())}",
              f"High/critical risk     : {int(w['Risk Level'].isin(['High', 'Critical']).sum())}"]
    if "Incidents" in perms:
        inc = d["incidents"]
        sec("SAFETY INCIDENTS")
        L += [f"Total incidents        : {len(inc)}", f"Open / not closed      : {int((inc['Corrective Action Status'] != 'Closed').sum())}",
              f"High or critical       : {int(inc['Severity'].isin(['High', 'Critical']).sum())}",
              f"Lost-time injuries     : {int((inc['Lost Time Injury'] == 'Yes').sum())}"]
        L += [f"  {r['Category']}: {r['Count']}" for _, r in counts(inc["Department"], "Category").iterrows()]
    if "Equipment" in perms:
        eq, sets = maintenance_sets(d)
        sec("EQUIPMENT CONDITION")
        L += [f"Total equipment        : {len(eq)}", f"Average availability   : {eq['Availability'].mean():.1f}%",
              f"Operating normally     : {(eq['Alert Status'] == 'NORMAL').mean():.0%}" if len(eq) else ""]
        L += [f"  {r['Equipment ID']}: {equipment_message(r)}" for _, r in eq[eq["Alert Status"] != "NORMAL"].iterrows()]
        sec("MAINTENANCE STATUS")
        L += [f"{name:<22}: {len(df)}" + (f"  ({', '.join(df['Equipment ID'])})" if len(df) else "") for name, df in sets.items()]
    if "Risk Assessment" in perms:
        rk = d["risk"]
        sec("RISK ASSESSMENTS")
        L.append(f"Assessments recorded   : {len(rk)}")
        L += [f"  {r['Category']}: {r['Count']}" for _, r in counts(rk["Risk Level"], "Category").iterrows()]
    sec("RECOMMENDATIONS")
    L += [f"- {r}" for r in recommendations(d, perms)]
    return "\n".join(x for x in L if x is not None)


def reports_page(d, perms, user):
    page_header("Reporting / decision support", "Generate reports", "Download a monitoring summary and the datasets you are permitted to view.")
    report = build_report(d, perms, user)
    st.download_button("Download monitoring report (.txt)", report.encode("utf-8"), f"monitoring_report_{date.today()}.txt", "text/plain", type="primary")
    st.text_area("Report preview", report, height=420, disabled=True)
    st.subheader("Dataset downloads")
    sources = [("Worker Safety", "workers"), ("Incidents", "incidents"), ("Equipment", "equipment"), ("Maintenance", "maintenance"), ("Risk Assessment", "risk")]
    allowed = [(p, k) for p, k in sources if p in perms]
    for col, (page, key) in zip(st.columns(max(len(allowed), 1)), allowed):
        with col:
            st.download_button(f"{page} (CSV)", d[key].drop(columns=["Alert Status"], errors="ignore").to_csv(index=False).encode("utf-8"), f"{key}.csv", "text/csv", key=f"dl_{key}")


# ---------------------------------------------------------------- users
def users_page():
    page_header("Administration / access control", "User management", "Create accounts, change roles, reset passwords and remove users.")
    users = get("users")
    me = st.session_state.user["Username"]
    show = users[["Username", "Name", "Role"]].assign(Pages=users["Role"].map(lambda r: len(PERMISSIONS.get(r, []))))
    st.dataframe(show, use_container_width=True, hide_index=True)
    admins = int((users["Role"] == "Administrator").sum())
    with st.expander("➕ Add user"):
        with st.form("add_user", clear_on_submit=True):
            un = st.text_input("Username *")
            nm = st.text_input("Full name *")
            role = st.selectbox("Role", ROLES)
            pw = st.text_input("Password * (minimum 8 characters)", type="password")
            pw2 = st.text_input("Confirm password *", type="password")
            go = st.form_submit_button("Create user", type="primary")
        if go:
            if not valid_id(un) or not nm.strip():
                st.error(f"Username and full name are required. {ID_HELP}")
            elif id_exists(users, "Username", un):
                st.error("That username already exists.")
            elif len(pw) < 8 or pw != pw2:
                st.error("Passwords must match and be at least 8 characters.")
            else:
                append_row("users", make_user(un, nm, role, pw))
                flash(f"User {un.strip().lower()} created.")
                st.rerun()
    with st.expander("Change role / reset password"):
        with st.form("edit_user"):
            target = st.selectbox("User", users["Username"].tolist())
            new_role = st.selectbox("New role", ROLES)
            new_pw = st.text_input("New password (leave blank to keep current)", type="password")
            go = st.form_submit_button("Save changes")
        if go:
            cur = users.loc[users["Username"] == target, "Role"].iloc[0]
            if cur == "Administrator" and new_role != "Administrator" and admins <= 1:
                st.error("At least one Administrator must remain.")
            elif new_pw and len(new_pw) < 8:
                st.error("New password must be at least 8 characters.")
            else:
                changes = {"Role": new_role}
                if new_pw:
                    salt = secrets.token_hex(16)
                    changes.update({"Salt": salt, "Password Hash": hash_pw(new_pw, salt)})
                update_cells("users", "Username", target, changes)
                flash(f"User {target} updated.")
                st.rerun()
    with st.expander("Delete user"):
        with st.form("del_user"):
            target = st.selectbox("User to delete", users["Username"].tolist())
            sure = st.checkbox("I understand this cannot be undone")
            go = st.form_submit_button("Delete user")
        if go:
            role = users.loc[users["Username"] == target, "Role"].iloc[0]
            if not sure:
                st.error("Tick the confirmation box first.")
            elif target == me:
                st.error("You cannot delete your own account while signed in.")
            elif role == "Administrator" and admins <= 1:
                st.error("At least one Administrator must remain.")
            else:
                write("users", users[users["Username"] != target])
                flash(f"User {target} deleted.")
                st.rerun()
    st.info("Passwords are stored as salted PBKDF2 hashes in data/users.csv. Production systems should use a managed identity provider.")


# ======================================================================================
# APP SHELL
# ======================================================================================
def login_page():
    inject_styles()
    _, mid, _ = st.columns([1, 1.3, 1])
    with mid:
        st.markdown('<div class="brand-mark">ST</div><span class="brand-title">SafeTrak Mining Systems</span>', unsafe_allow_html=True)
        st.markdown("## Operations intelligence for safer mines")
        st.caption("Sign in to monitor worker safety, incidents, equipment condition and maintenance.")
        with st.form("login_form"):
            username = st.text_input("Username", placeholder="e.g. safety")
            password = st.text_input("Password", type="password")
            submitted = st.form_submit_button("Sign in", type="primary", use_container_width=True)
        if submitted:
            if not username.strip() or not password:
                st.error("Enter both username and password.")
            else:
                user = verify_user(username, password)
                if user:
                    st.session_state.authenticated = True
                    st.session_state.user = user
                    st.rerun()
                st.error("Invalid username or password.")
       

def app():
    inject_styles()
    user = st.session_state.user
    perms = PERMISSIONS.get(user["Role"], {"Dashboard", "Reports"})
    d = load_all()
    with st.sidebar:
        st.markdown('<div class="brand"><span class="brand-mark">ST</span><span class="brand-title">SafeTrak Mining Systems</span></div>', unsafe_allow_html=True)
        st.caption(f"{user['Name']}  |  {user['Role']}")
        selected = st.radio("Navigate", [p for p in PAGES if p in perms], label_visibility="collapsed")
        st.markdown("---")
        st.caption("Prototype monitoring limits")
        st.caption(f"Temperature: {TEMP_WARN} / {TEMP_CRIT} °C")
        st.caption(f"Vibration: {VIB_WARN} / {VIB_CRIT} mm/s")
        if st.button("Sign out", use_container_width=True):
            st.session_state.pop("authenticated", None)
            st.session_state.pop("user", None)
            st.rerun()
    show_flash()
    if selected == "Dashboard":
        dashboard(d, perms)
    elif selected == "Worker Safety":
        worker_page(d)
    elif selected == "Incidents":
        incidents_page(d)
    elif selected == "Equipment":
        equipment_page(d)
    elif selected == "Maintenance":
        maintenance_page(d)
    elif selected == "Risk Assessment":
        risk_page(d)
    elif selected == "Analytics":
        analytics_page(d, perms)
    elif selected == "Reports":
        reports_page(d, perms, user)
    elif selected == "User Management":
        users_page()


def load_all():
    d = {k: get(k) for k in ["workers", "incidents", "equipment", "maintenance", "risk"]}
    d["alerts"] = build_alerts(d)
    return d


if not st.session_state.get("authenticated") or "user" not in st.session_state:
    login_page()
else:
    app()
