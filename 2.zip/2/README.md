# Mining Sentinel

Mining Sentinel is an educational Python/Streamlit prototype for mining health, safety, and equipment monitoring.

## Run locally

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

Open the local URL shown by Streamlit. Demo accounts:

| Username | Password | Role |
| --- | --- | --- |
| admin | admin123 | Administrator |
| safety | safety123 | Safety Officer |
| mining | mining123 | Mining Engineer |
| maint | maint123 | Maintenance Engineer |
| manager | manager123 | Manager |

## Included functions

- Role-based navigation for all five requested roles
- Dashboard KPIs and an operational alert queue
- Worker PPE, training, fatigue, near-miss, and risk monitoring
- Searchable and filterable incident database
- Equipment condition monitoring for temperature and vibration
- Maintenance priority view using downtime and availability
- Likelihood x consequence risk assessment
- Interactive questions using grouped Pandas data
- Explicit educational-threshold warning in the interface

The sample records are intentionally seeded in `app.py` so the prototype runs immediately. For a production version, move records to CSV/SQLite and replace in-memory demo authentication with hashed credentials and an identity provider. Equipment thresholds in this app are educational prototype values only and are not manufacturer or mine safety limits.
